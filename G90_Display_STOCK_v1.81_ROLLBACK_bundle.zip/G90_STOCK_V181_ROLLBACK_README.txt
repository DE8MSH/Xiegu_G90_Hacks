G90 DisplayUnit stock v1.81 rollback

Firmware: G90_DispUnit_Fw_V1.81_STOCK_ROLLBACK.xgf
Size: 132656 bytes
SHA-256: 8d48b9f23dbd75453c621cbf49fe50b30ba84d70564a3f97035e33cf4bbeb334

Flash command:

python3 flash_g90_display_stock_v181_safe.py G90_DispUnit_Fw_V1.81_STOCK_ROLLBACK.xgf /dev/serial/by-id/usb-FTDI_USB__-__Serial-if00-port0

Typed confirmation:
ROLLBACK DISPLAY STOCK 1.81

This script is locked to the exact stock v1.81 XGF above.
