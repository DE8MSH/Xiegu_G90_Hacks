# G90 v1.81 SAM — SAFE OFFLINE PATCH PLAN v0.1

**Status: NOT FLASHABLE. No XGF is included.**

## What is now verified from the actual v1.81 MainUnit binary

The stock AM detector is isolated unambiguously.

At `0x08009502` the DSP reads the internal demodulation mode.

- internal mode `6` enters the NFM path and calls `0x0800793C`
- internal mode `7` enters the AM path and calls `0x08007908`

This mapping is based on the algorithms themselves:
`0x0800793C` is a phase-difference / quadrature discriminator, while
`0x08007908` is an envelope detector.

### Stock AM call site

At `0x0800951C`:

```asm
ldr     r1, =0x20004C68     ; output buffer
str     r6, [sp,#0x30]      ; I buffer pointer
movs    r2, #32             ; 32 samples
add     r0, sp, #0x30       ; struct { I*, Q* }
str     r10,[sp,#0x34]      ; Q buffer pointer
bl      0x08007908          ; STOCK AM ENVELOPE DETECTOR
```

The exact four bytes of the stock BL at `0x08009528` are:

```text
FE F7 EE F9
```

### Stock AM detector `0x08007908`

The function is effectively:

```c
for (n = 0; n < 32; ++n)
    out[n] = 316.0f * sqrtf(I[n]*I[n] + Q[n]*Q[n]);
```

The `316.0f` constant is present at `0x08007938`.

That gives us an unusually clean SAM insertion point:
**replace only the AM detector call, leaving every upstream/downstream block unchanged.**

## Proposed first SAM implementation

The prototype in `sam_core.c`:

1. extracts a narrow complex carrier from the existing filtered I/Q,
2. normalizes the carrier phasor,
3. coherently projects I/Q onto it,
4. estimates carrier lock,
5. smoothly crossfades back to the exact stock envelope detector if lock is poor,
6. preserves the stock `x316` output scale and DC convention.

No trig, heap, malloc, filesystem, UART, display or TX code.

## RAM plan

The first candidate is to reuse the NFM discriminator state at `0x20000010`.

Why this is attractive:
- NFM and AM are mutually exclusive.
- The NFM routine at `0x0800793C` already owns this area only when internal mode=6.
- SAM would use it only when internal mode=7.
- A magic value (`0x53414D31`, "SAM1") forces clean reinitialization after switching modes.

This is **not yet accepted for flashing** until all cross-references to that RAM
window are audited.

## Flash plan

No patch has been made yet.

When accepted, the binary delta should be minimal:

1. append ~few hundred bytes of SAM code into verified-unused MainUnit flash,
2. replace the **single 32-bit BL instruction at `0x08009528`**,
3. modify nothing else in the existing executable code,
4. leave the bootloader, vector table, TX paths, SSB, CW and NFM untouched.

## Still required before any XGF is produced

- verify the exact sample rate of the I/Q buffers at this hook;
- audit `0x20000010...` RAM ownership completely;
- build a watchdog/fallback rule that cannot emit NaN/Inf;
- test zero input, huge input, carrier loss, frequency error, >100% modulation;
- inspect generated Cortex-M4F code for stack usage and external calls;
- byte-diff final candidate against stock and reject unexpected changes;
- retain original v1.81 MainUnit XGF as immediate rollback.

## Offline test result

Synthetic selective-fading test
Stock envelope: gain=1.0193 RMSE=0.129717 corr=0.889588
SAM tracker   : gain=1.0836 RMSE=0.015315 corr=0.998546
Mean SAM blend after startup: 1.000
WAV: /mnt/data/G90_SAM_v0.1_OFFLINE/sam_test_stock_left_sam_right.wav

