
/*
 * G90 SAM prototype core — OFFLINE / NOT FLASHABLE YET
 *
 * Target hook signature matches the stock AM envelope detector:
 *   src->i : float I[n]
 *   src->q : float Q[n]
 *   dst    : float output[n]
 *   n      : block length (stock caller uses 32)
 *
 * Stock AM detector at 0x08007908 computes:
 *     dst[k] = 316.0f * sqrt(I[k]^2 + Q[k]^2)
 *
 * This SAM core extracts a narrow complex carrier and coherently projects
 * I/Q onto that carrier.  If carrier lock is weak it crossfades back to
 * the exact envelope-detector behavior.
 *
 * No heap, no dynamic allocation, no trig functions.
 */

#include <stdint.h>

typedef struct {
    const float *i;
    const float *q;
} g90_iq_pair_t;

typedef struct {
    float carrier_i;
    float carrier_q;
    float env_ema;
    float blend;
    uint32_t magic;
} g90_sam_state_t;

#define G90_SAM_MAGIC 0x53414D31u /* "SAM1" */

static inline float clamp01(float x)
{
    return x < 0.0f ? 0.0f : (x > 1.0f ? 1.0f : x);
}

/*
 * alpha_carrier, alpha_env, alpha_blend MUST be set only after the actual
 * sample rate at this point in the stock DSP chain is verified.
 */
void g90_sam_process(
    g90_sam_state_t *s,
    const g90_iq_pair_t *src,
    float *dst,
    uint32_t n,
    float alpha_carrier,
    float alpha_env,
    float alpha_blend)
{
    if (!n) return;

    if (s->magic != G90_SAM_MAGIC) {
        float i0 = src->i[0];
        float q0 = src->q[0];
        s->carrier_i = i0;
        s->carrier_q = q0;
        s->env_ema = __builtin_sqrtf(i0*i0 + q0*q0);
        s->blend = 0.0f;
        s->magic = G90_SAM_MAGIC;
    }

    for (uint32_t k = 0; k < n; ++k) {
        float i = src->i[k];
        float q = src->q[k];

        /* Exact stock-envelope quantity before the x316 scaling. */
        float env = __builtin_sqrtf(i*i + q*q);

        /*
         * Narrow complex carrier extractor.
         * Because I and Q are filtered together, this preserves carrier phase.
         */
        s->carrier_i += alpha_carrier * (i - s->carrier_i);
        s->carrier_q += alpha_carrier * (q - s->carrier_q);

        float cp = s->carrier_i*s->carrier_i + s->carrier_q*s->carrier_q;
        float carrier_amp = __builtin_sqrtf(cp);

        /* Relative carrier-strength estimate for lock / fallback. */
        s->env_ema += alpha_env * (env - s->env_ema);
        float ratio = carrier_amp / (s->env_ema + 1.0e-12f);

        /*
         * 0 below ~8% extracted carrier, 1 above ~20%.
         * Blend is smoothed, so loss/reacquisition does not click.
         */
        float lock_target = clamp01((ratio - 0.08f) * (1.0f / 0.12f));
        s->blend += alpha_blend * (lock_target - s->blend);

        /* Coherent projection onto the recovered carrier phasor. */
        float coherent = env;
        if (carrier_amp > 1.0e-10f) {
            coherent = (i*s->carrier_i + q*s->carrier_q) / carrier_amp;
        }

        /*
         * Preserve the stock detector's output scale and DC convention.
         * Existing downstream audio filters can therefore remain untouched.
         */
        dst[k] = 316.0f *
            ((1.0f - s->blend) * env + s->blend * coherent);
    }
}
