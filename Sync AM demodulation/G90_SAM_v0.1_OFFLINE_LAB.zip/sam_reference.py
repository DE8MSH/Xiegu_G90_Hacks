
#!/usr/bin/env python3
"""Offline G90 SAM reference test. Does not touch a radio."""
import numpy as np
import math
import wave
from pathlib import Path

FS = 48000       # TEST ASSUMPTION ONLY; not yet accepted for a flash build.
DURATION = 5.0
CARRIER_TRACK_HZ = 80.0
ENV_TRACK_HZ = 5.0
BLEND_HZ = 8.0

def alpha(fc, fs):
    return 1.0 - math.exp(-2.0*math.pi*fc/fs)

def sam_process(i, q, fs=FS):
    ac = alpha(CARRIER_TRACK_HZ, fs)
    ae = alpha(ENV_TRACK_HZ, fs)
    ab = alpha(BLEND_HZ, fs)

    ci = float(i[0])
    cq = float(q[0])
    env_ema = math.hypot(ci, cq)
    blend = 0.0

    stock = np.empty(len(i), dtype=np.float64)
    sam = np.empty(len(i), dtype=np.float64)
    blend_trace = np.empty(len(i), dtype=np.float64)

    for n, (ii, qq) in enumerate(zip(i, q)):
        env = math.hypot(ii, qq)
        stock[n] = env

        ci += ac * (ii - ci)
        cq += ac * (qq - cq)

        carrier_amp = math.hypot(ci, cq)
        env_ema += ae * (env - env_ema)
        ratio = carrier_amp / (env_ema + 1e-12)

        target = max(0.0, min(1.0, (ratio - 0.08) / 0.12))
        blend += ab * (target - blend)

        coherent = env if carrier_amp <= 1e-10 else (ii*ci + qq*cq)/carrier_amp
        sam[n] = (1.0-blend)*env + blend*coherent
        blend_trace[n] = blend

    return stock, sam, blend_trace

def dc_remove(x, fs, fc=20.0):
    a = alpha(fc, fs)
    dc = 0.0
    y = np.empty_like(x)
    for n,v in enumerate(x):
        dc += a*(v-dc)
        y[n] = v-dc
    return y

def fit_metrics(y, target, start):
    yy = y[start:]
    tt = target[start:]
    gain = float(np.dot(yy,tt)/np.dot(yy,yy))
    pred = gain*yy
    rmse = float(np.sqrt(np.mean((pred-tt)**2)))
    corr = float(np.corrcoef(pred,tt)[0,1])
    return gain,rmse,corr

def main():
    fs=FS
    t=np.arange(int(fs*DURATION))/fs

    # Audio-like multi-tone modulation.
    tones=[(700,0.35),(1300,0.18),(2200,0.08)]
    modulation=sum(a*np.cos(2*np.pi*f*t) for f,a in tones)

    # Carrier has residual tuning error and selective fading.
    foff=35.0 + 8.0*np.sin(2*np.pi*0.2*t)
    phase=np.cumsum(2*np.pi*foff/fs)+0.5
    carrier_amp=0.55 + 0.45*np.sin(2*np.pi*0.6*t)
    carrier_amp=np.clip(carrier_amp,0.03,1.0)

    # Sidebands do NOT fade exactly with the carrier: selective-fading case.
    z=carrier_amp*np.exp(1j*phase)
    for f,a in tones:
        z += (a/2)*np.exp(1j*(phase+2*np.pi*f*t))
        z += (a/2)*np.exp(1j*(phase-2*np.pi*f*t))

    rng=np.random.default_rng(1)
    z += 0.005*(rng.normal(size=len(t))+1j*rng.normal(size=len(t)))

    stock,sam,blend=sam_process(z.real,z.imag,fs)

    stock_audio=dc_remove(stock,fs)
    sam_audio=dc_remove(sam,fs)

    start=fs # discard first second
    mg=fit_metrics(stock_audio,modulation,start)
    sg=fit_metrics(sam_audio,modulation,start)

    print("Synthetic selective-fading test")
    print(f"Stock envelope: gain={mg[0]:.4f} RMSE={mg[1]:.6f} corr={mg[2]:.6f}")
    print(f"SAM tracker   : gain={sg[0]:.4f} RMSE={sg[1]:.6f} corr={sg[2]:.6f}")
    print(f"Mean SAM blend after startup: {blend[start:].mean():.3f}")

    # Normalize and write stereo WAV: L=stock, R=SAM.
    left=stock_audio[start:]
    right=sam_audio[start:]
    peak=max(np.max(np.abs(left)),np.max(np.abs(right)),1e-12)
    left=np.clip(left/peak*0.9,-1,1)
    right=np.clip(right/peak*0.9,-1,1)

    out=Path(__file__).with_name("sam_test_stock_left_sam_right.wav")
    with wave.open(str(out),"wb") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(fs)
        inter=np.empty(left.size*2,dtype=np.int16)
        inter[0::2]=(left*32767).astype(np.int16)
        inter[1::2]=(right*32767).astype(np.int16)
        w.writeframes(inter.tobytes())
    print("WAV:",out)

if __name__=="__main__":
    main()
